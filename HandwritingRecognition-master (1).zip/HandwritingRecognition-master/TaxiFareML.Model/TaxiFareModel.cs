﻿namespace TaxiFareML.Model;

public class TaxiFareModel
{
    public const string Name = "TaxiFareModel";
}