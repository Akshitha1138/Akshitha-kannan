﻿namespace HandwritingRecognitionML.Model;

public class HwrModel
{
    public const string Name = "HWR";
}