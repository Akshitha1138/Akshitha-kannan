using HandwritingRecognitionML.ConsoleApp;

ModelBuilder.CreateModel();

Console.WriteLine("=============== End of process ===============");